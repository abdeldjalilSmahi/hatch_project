from shared import Reader

def function():
    r = Reader()
    r.read()