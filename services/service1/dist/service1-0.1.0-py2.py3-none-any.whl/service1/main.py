from service1.src import function

def main():
    function()



