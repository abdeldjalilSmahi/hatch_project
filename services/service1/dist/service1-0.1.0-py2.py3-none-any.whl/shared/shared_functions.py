import pandas as pd

class Reader:

    def read(self):
        print("hello")